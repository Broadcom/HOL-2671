# uistart.sh - version 1.0 - 3 February 2023

#!/bin/bash
export PYTHONUNBUFFERED=1
/usr/bin/python3 /hol/hol-2571/hol_modswitcher/main_ui.py --dir /hol/hol-2571/hol_modswitcher/

