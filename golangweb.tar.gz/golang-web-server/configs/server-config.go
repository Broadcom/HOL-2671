package configs

const (
	SERVER_STATIC_DIRECTORY string = "./web/static"
	SERVER_URL              string = "0.0.0.0"
	SERVER_PORT             string = "8081"
)
